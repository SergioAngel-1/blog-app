import React, { useState, useEffect } from 'react';
import { Article } from '../types/Article';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface ArticleCarouselProps {
  articles: Article[];
}

const ArticleCarousel: React.FC<ArticleCarouselProps> = ({ articles }) => {
  // ... (código anterior sin cambios)

  if (articles.length === 0) return null;

  return (
    <div id="article-carousel" className="relative w-full h-64 overflow-hidden rounded-lg shadow-lg">
      {articles.map((article, index) => (
        <div
          key={article.id}
          id={`carousel-item-${article.id}`}
          className={`absolute w-full h-full transition-opacity duration-500 ${
            index === currentIndex ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img
            src={`https://source.unsplash.com/random/800x400?${article.type}`}
            alt={article.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-4">
            <h3 className="text-xl font-bold">{article.title}</h3>
            <p className="text-sm">{article.author}</p>
          </div>
        </div>
      ))}
      <button
        id="carousel-prev-btn"
        onClick={prevSlide}
        className="absolute top-1/2 left-2 transform -translate-y-1/2 bg-white bg-opacity-50 rounded-full p-2"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        id="carousel-next-btn"
        onClick={nextSlide}
        className="absolute top-1/2 right-2 transform -translate-y-1/2 bg-white bg-opacity-50 rounded-full p-2"
      >
        <ChevronRight size={24} />
      </button>
    </div>
  );
};

export default ArticleCarousel;