import React from 'react';
import { Article } from '../types/Article';
import { Edit } from 'lucide-react';

interface ArticleListProps {
  articles: Article[];
  onEdit: (article: Article) => void;
}

const ArticleList: React.FC<ArticleListProps> = ({ articles, onEdit }) => {
  return (
    <div id="article-list" className="space-y-4">
      {articles.map((article) => (
        <div key={article.id} id={`article-${article.id}`} className="bg-white p-4 rounded-lg shadow">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xl font-bold">{article.title}</h3>
              <p className="text-sm text-gray-600">
                Por {article.author} | {new Date(article.createdAt).toLocaleDateString()}
              </p>
            </div>
            <button
              onClick={() => onEdit(article)}
              className="text-blue-600 hover:text-blue-800"
              aria-label={`Editar artículo: ${article.title}`}
            >
              <Edit size={20} />
            </button>
          </div>
          <p className="mt-2 text-gray-700">{article.content.substring(0, 150)}...</p>
          <p className="mt-2 text-sm text-gray-500">Tipo: {article.type}</p>
        </div>
      ))}
    </div>
  );
};

export default ArticleList;