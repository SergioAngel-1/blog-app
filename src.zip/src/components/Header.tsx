import React from 'react';
import { Newspaper } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header id="main-header" className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Newspaper size={32} />
          <h1 id="site-title" className="text-2xl font-bold">Mi Blog</h1>
        </div>
      </div>
    </header>
  );
};

export default Header;